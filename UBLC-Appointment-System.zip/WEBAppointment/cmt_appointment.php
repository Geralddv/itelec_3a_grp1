<?php
session_start(); 

$host = "localhost:3307"; 
$username = "root";
$password = "";
$dbname = "appointment";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (!isset($_SESSION['studentnumber'])) {
    header("Location: login.html"); 
    exit();
}

$studentnumber = $_SESSION['studentnumber']; 
$successMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $studentname = $_POST['studentname'] ?? '';
    $professor = $_POST['professor'] ?? '';
    $purpose = $_POST['purpose'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';

    
    $currentDate = date("Y-m-d");
    if ($date < $currentDate) {
        $successMessage = "Error: Appointment date cannot be in the past.";
    } else {
        
        $sql = "INSERT INTO tblcmtappointment (studentname, studentnumber, professor, purpose, date, time) VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("ssssss", $studentname, $studentnumber, $professor, $purpose, $date, $time);

            if ($stmt->execute()) {
                $successMessage = "Appointment submitted, wait for confirmation";
            } else {
                $successMessage = "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $successMessage = "Error preparing the statement: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CMT Appointment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #fff;
            color: #400000;
        }
        .navbar {
            background-color: #800000;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }
        .navbar a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: bold;
        }
        .header {
            text-align: center;
            padding: 2rem 0;
            background-color: #f2f2f2;
            font-size: 1.5rem;
            color: #400000;
        }
        .container {
            margin: 2rem auto;
            max-width: 600px;
            padding: 2rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fff;
        }
        label {
            display: block;
            margin: 1rem 0 0.5rem;
        }
        select, input[type="text"], input[type="date"], input[type="time"] {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #800000;
            border-radius: 4px;
        }
        .button {
            background-color: #800000;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            cursor: pointer;
            border-radius: 4px;
            display: block;
            width: 100%;
            font-size: 1rem;
        }
        .button:hover {
            background-color: #990000;
        }
    </style>
    <script>
        function showAlertAndRedirect(message) {
            alert(message);
            window.location.href = 'home.html';
        }
    </script>
</head>
<body>
    <div class="navbar">
        <div><strong>CMT Appointment</strong></div>
        <div>
            <a href="notification.php">Notification</a>
            <a href="profile.html">Profile</a>
        </div>
    </div>

    <div class="header">
        College of Management and Tourism
    </div>

    <div class="container">
        <form action="#" method="post">
            <label for="studentname">Student Name:</label>
            <input type="text" id="studentname" name="studentname" placeholder="Enter your name" required>

            <label for="professor">Select Professor:</label>
            <select id="professor" name="professor" required>
                <option id="prof1" value="prof1">Dean.</option>
                <option id="prof2" value="prof2">Ms.</option>
                <option id="prof3" value="prof3">Mr.</option>
            </select>

            <label for="purpose">Purpose of Appointment:</label>
            <select id="purpose" name="purpose" required>
                <option id="advising" value="Advising">Advising</option>
                <option id="consultation" value="Consultation">Consultation</option>
                <option id="office_hours" value="Office hours">Office Hours</option>
                <option id="project_discussion" value="Project discussion">Project Discussion</option>
                <option id="completion_form" value="Completion form">Completion Form</option>
                <option id="dean_signiture" value="Dean signiture">Dean's Signature</option>
                <option id="program_head_signiture" value="Program head signiture">Program Head's Signature</option>
                <option id="others" value="Others">Others</option>
            </select>

            <label for="date">Set Date:</label>
            <input type="date" id="date" name="date" min="<?php echo date('Y-m-d'); ?>" required>

            <label for="time">Set Time:</label>
            <input type="time" id="time" name="time" required>

            <button type="submit" class="button">Submit</button>
            <br>
            <button type="button" class="button" onclick="window.location.href='home.html'">Cancel</button>
        </form>
    </div>
    
    <?php if ($successMessage): ?>
        <script>
            showAlertAndRedirect("<?php echo $successMessage; ?>");
        </script>
    <?php endif; ?>
</body>
</html>
