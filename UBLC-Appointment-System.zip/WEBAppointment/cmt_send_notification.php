<?php
session_start();

$db = mysqli_connect("localhost:3307", "root", "", "appointment");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $id_appoint = isset($_POST['id_appoint']) ? intval($_POST['id_appoint']) : null;
    $action = isset($_POST['action']) ? trim($_POST['action']) : null;
    $message = isset($_POST['message']) ? trim($_POST['message']) : null;

    
    if ($id_appoint && $action && $message) {
        
        $fetch_query = "SELECT studentnumber FROM tblcmtappointment WHERE id_appoint = ?";
        $fetch_stmt = mysqli_prepare($db, $fetch_query);

        if ($fetch_stmt) {
            mysqli_stmt_bind_param($fetch_stmt, "i", $id_appoint);
            mysqli_stmt_execute($fetch_stmt);
            mysqli_stmt_bind_result($fetch_stmt, $studentnumber);
            mysqli_stmt_fetch($fetch_stmt);
            mysqli_stmt_close($fetch_stmt);

            if ($studentnumber) {
                
                $new_status = ($action === 'Approve') ? 'accepted' : 'cancelled';
                $update_query = "UPDATE tblcmtappointment SET status = ? WHERE id_appoint = ?";
                $update_stmt = mysqli_prepare($db, $update_query);

                if ($update_stmt) {
                    mysqli_stmt_bind_param($update_stmt, "si", $new_status, $id_appoint);

                    if (mysqli_stmt_execute($update_stmt)) {
                        
                        $insert_query = "INSERT INTO notifications (studentnumber, id_appoint, action, message, status, created_at) 
                                         VALUES (?, ?, ?, ?, 'unread', NOW())";
                        $insert_stmt = mysqli_prepare($db, $insert_query);

                        if ($insert_stmt) {
                            mysqli_stmt_bind_param($insert_stmt, "siss", $studentnumber, $id_appoint, $action, $message);

                            if (mysqli_stmt_execute($insert_stmt)) {
                                
                                echo json_encode([
                                    'status' => 'success',
                                    'message' => 'Notification sent and appointment status updated successfully.',
                                    'redirect' => 'cmt_admindashboard.php',
                                    'id_appoint' => $id_appoint,
                                    'new_status' => $new_status,
                                ]);
                                exit;
                            } else {
                                echo json_encode([
                                    'status' => 'error',
                                    'message' => 'Error inserting notification: ' . mysqli_stmt_error($insert_stmt),
                                ]);
                                exit;
                            }

                            mysqli_stmt_close($insert_stmt);
                        } else {
                            echo json_encode([
                                'status' => 'error',
                                'message' => 'Error preparing insert query: ' . mysqli_error($db),
                            ]);
                            exit;
                        }
                    } else {
                        echo json_encode([
                            'status' => 'error',
                            'message' => 'Error updating appointment status: ' . mysqli_stmt_error($update_stmt),
                        ]);
                        exit;
                    }

                    mysqli_stmt_close($update_stmt);
                } else {
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Error preparing update query: ' . mysqli_error($db),
                    ]);
                    exit;
                }
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error: No student found for the given appointment ID.',
                ]);
                exit;
            }
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Error preparing fetch query: ' . mysqli_error($db),
            ]);
            exit;
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Error: Missing required fields (id_appoint, action, message).',
        ]);
        exit;
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Error: Invalid request method.',
        
    ]);
    exit;
}

mysqli_close($db);
?>