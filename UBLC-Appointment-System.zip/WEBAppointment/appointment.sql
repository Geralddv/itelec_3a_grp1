-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Nov 24, 2024 at 05:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `studentnumber` varchar(50) NOT NULL,
  `id_appoint` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `status` enum('unread','read') DEFAULT 'unread'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblccjeappointment`
--

CREATE TABLE `tblccjeappointment` (
  `id_appoint` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `studentnumber` int(100) NOT NULL,
  `professor` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblceasappointment`
--

CREATE TABLE `tblceasappointment` (
  `id_appoint` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `studentnumber` int(100) NOT NULL,
  `professor` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblcenarappointment`
--

CREATE TABLE `tblcenarappointment` (
  `id_appoint` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `studentnumber` int(100) NOT NULL,
  `professor` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblcitecappointment`
--

CREATE TABLE `tblcitecappointment` (
  `id_appoint` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `studentnumber` int(100) NOT NULL,
  `professor` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblcmtappointment`
--

CREATE TABLE `tblcmtappointment` (
  `id_appoint` int(11) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `studentnumber` int(50) NOT NULL,
  `professor` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblloginadmin`
--

CREATE TABLE `tblloginadmin` (
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblloginadmin`
--

INSERT INTO `tblloginadmin` (`email`, `password`) VALUES
('ccjedepartment@gmail.com', 'ccje'),
('ceasdepartment@gmail.com', 'ceas'),
('cenardepartment@gmail.com', 'cenar'),
('citecdepartment@gmail.com', 'citec'),
('cmtdepartment@gmail.com', 'cmt');

-- --------------------------------------------------------

--
-- Table structure for table `tblregistration`
--

CREATE TABLE `tblregistration` (
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `studentnumber` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblccjeappointment`
--
ALTER TABLE `tblccjeappointment`
  ADD PRIMARY KEY (`id_appoint`);

--
-- Indexes for table `tblceasappointment`
--
ALTER TABLE `tblceasappointment`
  ADD PRIMARY KEY (`id_appoint`);

--
-- Indexes for table `tblcenarappointment`
--
ALTER TABLE `tblcenarappointment`
  ADD PRIMARY KEY (`id_appoint`);

--
-- Indexes for table `tblcitecappointment`
--
ALTER TABLE `tblcitecappointment`
  ADD PRIMARY KEY (`id_appoint`);

--
-- Indexes for table `tblcmtappointment`
--
ALTER TABLE `tblcmtappointment`
  ADD PRIMARY KEY (`id_appoint`);

--
-- Indexes for table `tblloginadmin`
--
ALTER TABLE `tblloginadmin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `tblregistration`
--
ALTER TABLE `tblregistration`
  ADD PRIMARY KEY (`studentnumber`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `studentnumber` (`studentnumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `tblccjeappointment`
--
ALTER TABLE `tblccjeappointment`
  MODIFY `id_appoint` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblceasappointment`
--
ALTER TABLE `tblceasappointment`
  MODIFY `id_appoint` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblcenarappointment`
--
ALTER TABLE `tblcenarappointment`
  MODIFY `id_appoint` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblcitecappointment`
--
ALTER TABLE `tblcitecappointment`
  MODIFY `id_appoint` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tblcmtappointment`
--
ALTER TABLE `tblcmtappointment`
  MODIFY `id_appoint` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
