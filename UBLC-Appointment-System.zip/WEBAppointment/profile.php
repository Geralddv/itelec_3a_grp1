<?php
session_start();

if (!isset($_SESSION['studentnumber'])) {
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        .navbar {
            display: flex;
            justify-content: space-between; 
            align-items: center;
            background-color: #6e1927;
            padding: 10px 20px;
        }

        .navbar-links {
            margin-right: 15px; 
        }

        .navbar-links a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            margin-left: 20px;
            transition: color 0.3s;
        }

        .navbar-links a:hover {
            color: #ccc; 
        }

        .navbar-logo img {
            height: 80px;
            width: auto;
            margin-left: 15px;
        }

        .form-container-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 90vh;
            background-color: #f2f2f2;
        }

        .form-container {
            background-color: white;
            padding: 30px;
            width: 100%;
            max-width: 400px;
            border: 2px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center; 
        }

        .form-container h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .profile-container img {
            max-width: 120px; 
            height: 120px;
            border-radius: 50%;
            margin-bottom: 20px;
        }

        .form-container label {
            display: block;
            margin-bottom: 15px;
            font-size: 16px;
        }

        .form-container button {
            padding: 10px 20px;
            background-color: #6e1927;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }

        .form-container button:hover {
            background-color: #4b1220;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <a href="#" class="navbar-logo">
        <img src="logo.png" alt="Logo" />
    </a>
    <div class="navbar-links">
        <a href="home.html" class="navbar-home">Home</a>
    </div>
</nav>

<div class="form-container-wrapper">
    <div class="form-container">
        <h2>Student Profile</h2>

        <div class="profile-container">
            <img id="profile-image" src="user.png" alt="Student Image" />
        </div>

        <form action="#" method="post">
            <label>Full Name: <?php echo htmlspecialchars($_SESSION['fullname']); ?></label>
            <label>Student Number: <?php echo htmlspecialchars($_SESSION['studentnumber']); ?></label>
            <label>Email Address: <?php echo htmlspecialchars($_SESSION['email']); ?></label>
            <label>Department: <?php echo htmlspecialchars($_SESSION['department']); ?></label>

            <button type="button" onclick="window.location.href='login.html'">Logout</button>
        </form>
    </div>
</div>
</body>
</html>