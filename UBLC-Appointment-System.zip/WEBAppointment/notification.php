<?php
session_start(); // Ensure session is active

// Ensure the user is logged in
if (!isset($_SESSION['studentnumber'])) {
    header("Location: login.html");
    exit();
}

// Get the logged-in user's studentnumber
$studentnumber = $_SESSION['studentnumber'];

// Database connection
$db = mysqli_connect("localhost:3307", "root", "", "appointment");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Mark notifications as read when the page is loaded
$mark_read_query = "UPDATE notifications SET status = 'read' WHERE studentnumber = ? AND status = 'unread'";
$mark_read_stmt = mysqli_prepare($db, $mark_read_query);
if ($mark_read_stmt) {
    mysqli_stmt_bind_param($mark_read_stmt, "s", $studentnumber);
    mysqli_stmt_execute($mark_read_stmt);
    mysqli_stmt_close($mark_read_stmt);
}

// Fetch notifications for the logged-in student
$query = "SELECT id, id_appoint, action, message, status, created_at 
          FROM notifications 
          WHERE studentnumber = ? 
          ORDER BY created_at DESC";
$stmt = mysqli_prepare($db, $query);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, "s", $studentnumber);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $notifications = [];
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $notifications[] = $row;
        }
    }
    mysqli_stmt_close($stmt);
} else {
    die("Query failed: " . mysqli_error($db));
}

// Handle delete notification request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = intval($_POST['delete_id']);
    $delete_query = "DELETE FROM notifications WHERE id = ?";
    $delete_stmt = mysqli_prepare($db, $delete_query);

    if ($delete_stmt) {
        mysqli_stmt_bind_param($delete_stmt, "i", $delete_id);
        mysqli_stmt_execute($delete_stmt);
        mysqli_stmt_close($delete_stmt);
        echo "<script>alert('Notification deleted successfully.'); window.location.href='notification.php';</script>";
    } else {
        echo "<script>alert('Error deleting notification.'); window.location.href='notification.php';</script>";
    }
}

mysqli_close($db);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link rel="stylesheet" href="notif.css">
    <style>
        /* Custom styles for Approve and Cancel notifications */
        .approve-title {
            color: green;
            font-weight: bold;
        }

        .cancel-title {
            color: red;
            font-weight: bold;
        }

        .notification-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .notification {
            width: 80%; /* Adjust size of notification */
            max-width: 600px; /* Ensure a maximum size */
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <h1>UBLC Appointment System</h1>
        <ul>
            <li><a href="home.html">Home</a></li>
            <li><a href="profile.php">Profile</a></li>
        </ul>
    </div>

    <!-- Notifications Section -->
    <div class="container notification-container">
        <h1>Notifications</h1>

        <?php if (!empty($notifications)): ?>
            <?php foreach ($notifications as $notification): ?>
                <div class="notification <?php echo $notification['status'] == 'unread' ? 'unread' : ''; ?>">
                    <h4 class="<?php 
                        echo strtolower($notification['action']) === 'approve' ? 'approve-title' : 
                        (strtolower($notification['action']) === 'cancel' ? 'cancel-title' : '');
                    ?>">
                        <?php echo htmlspecialchars($notification['action']); ?>
                    </h4>
                    <p><?php echo htmlspecialchars($notification['message']); ?></p>
                    <small><?php echo date("F j, Y, g:i a", strtotime($notification['created_at'])); ?></small>
                    <form method="POST" style="margin-top: 10px;">
                        <input type="hidden" name="delete_id" value="<?php echo $notification['id']; ?>">
                        <button type="submit" class="delete-btn">Delete</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-notifications">No notifications available.</p>
        <?php endif; ?>
    </div>
</body>
</html>
