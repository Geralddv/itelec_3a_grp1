<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard College of Management and Tourism</title>
    <style>
body {
        background-color: #F1E6D3; 
        font-family: Arial, sans-serif;
        margin: 0;
        display: flex;
    }

    .nav-bar {
        width: 250px;
        background-color: #800000; 
        color: white;
        display: flex;
        flex-direction: column;
        height: 100vh;
        position: fixed;
    }

    .nav-bar img {
        width: 100px; 
        height: auto; 
        margin: 20px auto; 
        display: block;
    }

    .nav-bar a {
        color: white;
        text-decoration: none;
        padding: 15px;
        text-align: center;
        display: block;
    }

    .nav-bar a:hover {
        background-color: #9c2a2a; 
    }

    .nav-bar .logout {
        margin-top: auto;
    }

    .container {
        margin-left: 250px; 
        padding: 20px;
        flex-grow: 1;
    }

    .myheader {
        text-align: center;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        border: 1px solid #ccc;
    }

    th, td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: left; 
    }

    th {
        background-color: #800000; 
        color: #fff;
    }

    .btn-update {
        background-color: #28a745; 
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .btn-delete {
        background-color: #dc3545; 
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .tab {
        display: none;
    }

    .tab.active {
        display: block;
    }

    .table-responsive {
        overflow-x: auto;
    }

    .modal {
    display: none; 
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    z-index: 1001;
}

.modal.active {
    display: block; 
}

.overlay {
    display: none; 
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
}

.overlay.active {
    display: block; 
}

.filter-container {
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

</style>

<script>
    function openTab(tabName) {
        var i, tabcontent;
     
        tabcontent = document.getElementsByClassName("tab");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].className = tabcontent[i].className.replace(" active", "");
        }
     
        document.getElementById(tabName).className += " active";

     
        var headerText = document.getElementById("header-text");
        if (tabName === "PendingAppointment") {
            headerText.textContent = "CMT Admin Dashboard";
        } else if (tabName === "AcceptedAppointment") {
            headerText.textContent = "Approved Appointments";
        } else if (tabName === "DeclinedAppointment") {
            headerText.textContent = "Cancelled Appointments";
        }
    }

    function openModal(action, id_appoint) {
    const modal = document.getElementById("messageModal");
    const overlay = document.getElementById("overlay");
    const title = document.getElementById("modalTitle");

    modal.classList.add("active");
    overlay.classList.add("active");

    document.getElementById("modalAction").value = action;
    document.getElementById("modalid_appoint").value = id_appoint;

    if (action === 'Cancel') {
        title.textContent = "Cancel Appointment - Send Message";
    } else if (action === 'Approve') {
        title.textContent = "Approve Appointment - Send Message";
    }
}

function closeModal() {
    const modal = document.getElementById("messageModal");
    const overlay = document.getElementById("overlay");

    modal.classList.remove("active");
    overlay.classList.remove("active");
}
document.addEventListener('DOMContentLoaded', function () {
document.querySelector('form[action="cmt_send_notification.php"]').addEventListener('submit', function (e) {
    e.preventDefault(); 

    const formData = new FormData(this);

    fetch('cmt_send_notification.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const row = document.querySelector(`tr[data-id='${data.id_appoint}']`);
                if (row) {
                    if (data.new_status === 'accepted') {
                        document.getElementById('AcceptedAppointment').querySelector('table').appendChild(row);
                    }
                    row.style.display = 'none'; 
                }
                alert(data.message);
                window.location.href = 'cmt_admindashboard.php'; 
            } else {
                alert(data.message);
            }
            closeModal();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An unexpected error occurred.');
        });
    });
});
    
    function filterByDate(tableIds, filterDate) {
    if (!Array.isArray(tableIds)) {
        tableIds = [tableIds]; 
    }

    tableIds.forEach((tableId) => {
        const table = document.getElementById(tableId);
        const rows = table.getElementsByTagName('tr');

        for (let i = 1; i < rows.length; i++) { 
            const dateCell = rows[i].getElementsByTagName('td')[4]; 
            if (dateCell) {
                let cellDate = dateCell.querySelector('input')
                    ? dateCell.querySelector('input').value 
                    : dateCell.textContent.trim(); 

                
                const formattedCellDate = new Date(cellDate).toISOString().split('T')[0];
                const formattedFilterDate = new Date(filterDate).toISOString().split('T')[0];

                
                console.log("Row Date:", formattedCellDate, "| Filter Date:", formattedFilterDate);

                
                if (filterDate === "" || formattedCellDate === formattedFilterDate) {
                    rows[i].style.display = ""; 
                } else {
                    rows[i].style.display = "none"; 
                }
            }
        }
    });
}
</script>


</head>
<body>
    <div class="nav-bar">
        <img src="UBlogo.png" alt="CITEC Logo">
        <a onclick="openTab('PendingAppointment')">Pending Appointment</a>
        <a onclick="openTab('AcceptedAppointment')">Approved Appointment</a>
        <a href="index.html" class="logout">Log Out</a>
    </div>

    <div class="container">
        <div class="myheader">
            <h1 id="header-text">CMT Admin Dashboard</h1>
        </div>

        <div class="filter-container">
            <label for="dateFilter">Filter by Date:</label>
            <input type="date" id="dateFilter" onchange="filterByDate(['PendingAppointment', 'AcceptedAppointment'], this.value)">
        </div>

    <!-- PENDING APPOINTMENT -->
    <div id="PendingAppointment" class="tab active">
        <div class="table-responsive">
            <?php
            $db = mysqli_connect("localhost:3307", "root", "", "appointment");
            if (!$db) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $result = mysqli_query($db, "SELECT * FROM tblcmtappointment WHERE status IS NULL OR status = ''");

            echo "<table>";
            echo "<tr>
                    <th>Appointment ID</th>
                    <th>Student Name</th>
                    <th>Student Number</th>
                    <th>Professor</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Purpose</th>
                    <th colspan='2'>Manage</th>                            
                  </tr>";

            while ($myrow = mysqli_fetch_array($result)) {
                $id_appoint = $myrow['id_appoint'] ?? '';
                $studentname = $myrow['studentname'] ?? '';
                $studentnumber = $myrow['studentnumber'] ?? '';
                $professor = $myrow['professor'] ?? '';
                $date = $myrow['date'] ?? '';
                $time = $myrow['time'] ?? '';
                $purpose = $myrow['purpose'] ?? '';             

                echo "<tr>";
                echo "<form action='cmt_adminmanage.php' method='post'>";
                echo "<td><input type='text' name='id_appoint' value='" . htmlspecialchars($id_appoint) . "'></td>";
                echo "<td><input type='text' name='studentname' value='" . htmlspecialchars($studentname) . "' readonly></td>";
                echo "<td><input type='text' name='studentnumber' value='" . htmlspecialchars($studentnumber) . "' readonly></td>";
                echo "<td><input type='text' name='professor' value='" . htmlspecialchars($professor) . "' readonly></td>";
                echo "<td><input type='date' name='date' value='" . htmlspecialchars($date) . "' readonly></td>";
                echo "<td><input type='time' name='time' value='" . htmlspecialchars($time) . "' readonly></td>";
                echo "<td><input type='text' name='purpose' value='" . htmlspecialchars($purpose) . "' readonly></td>";
                echo "<td>
                        <center>
                            <div style='display: flex; gap: 10px; justify-content: center;'>
                                <button type='button' class='btn-update' onclick=\"openModal('Approve', '" . htmlspecialchars($id_appoint) . "')\">Approve</button>
                                <button type='button' class='btn-delete' onclick=\"openModal('Cancel', '" . htmlspecialchars($id_appoint) . "')\">Cancel</button>
                            </div>
                        </center>
                    </td>";
                echo "</form>";
                echo "</tr>";
            }

            mysqli_close($db);
        ?>
        </table>
    </div>
</div>

<!-- ACCEPTED APPOINTMENT -->
<div id="AcceptedAppointment" class="tab">
    <div class="table-responsive">
        <?php
            $db = mysqli_connect("localhost:3307", "root", "", "appointment");
            if (!$db) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $resultAcc = mysqli_query($db, "SELECT * FROM tblcmtappointment WHERE status = 'accepted'");

            echo "<table>";
            echo "<tr>
                    <th>Appointment ID</th>
                    <th>Student Name</th>
                    <th>Student Number</th>
                    <th>Professor</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Purpose</th>
                    <th>Manage</th>
                  </tr>";

            while ($rowAcc = mysqli_fetch_array($resultAcc)) {
                $id_appoint = $rowAcc['id_appoint'] ?? '';
                $studentname = $rowAcc['studentname'] ?? '';
                $studentnumber = $rowAcc['studentnumber'] ?? '';
                $professor = $rowAcc['professor'] ?? '';
                $date = $rowAcc['date'] ?? '';
                $time = $rowAcc['time'] ?? '';
                $purpose = $rowAcc['purpose'] ?? '';

                echo "<tr>";
                echo "<td>" . htmlspecialchars($id_appoint) . "</td>";
                echo "<td>" . htmlspecialchars($studentname) . "</td>";
                echo "<td>" . htmlspecialchars($studentnumber) . "</td>";
                echo "<td>" . htmlspecialchars($professor) . "</td>";
                echo "<td><input type='date' name='date' value='" . htmlspecialchars($date) . "' readonly></td>";
                echo "<td>" . htmlspecialchars($time) . "</td>";
                echo "<td>" . htmlspecialchars($purpose) . "</td>";
                echo "<td>
                        <center>
                            <div style='display: flex; gap: 10px; justify-content: center;'>
                                <button type='button' class='btn-update' onclick=\"openModal('Reschedule', '" . htmlspecialchars($id_appoint) . "')\">Reschedule</button>
                                <form action='' method='post' onsubmit=\"return confirm('Are you sure you want to delete this appointment?');\" style='margin: 0;'>
                                    <input type='hidden' name='delete_id' value='" . htmlspecialchars($id_appoint) . "'>
                                    <button type='submit' class='btn-delete'>Delete</button>
                                </form>
                            </div>
                        </center>
                    </td>";
            }

            mysqli_close($db);

            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
                $db = mysqli_connect("localhost:3307", "root", "", "appointment");
                if (!$db) {
                    die("Connection failed: " . mysqli_connect_error());
                }
            
                $delete_id = mysqli_real_escape_string($db, $_POST['delete_id']);
                $delete_query = "DELETE FROM tblcmtappointment WHERE id_appoint = '$delete_id'";
            
                if (mysqli_query($db, $delete_query)) {
                    echo "<script>alert('Appointment deleted successfully!');</script>";
                    echo "<script>window.location.href = window.location.href;</script>"; // Refresh the page
                } else {
                    echo "<script>alert('Error deleting appointment: " . mysqli_error($db) . "');</script>";
                }
            
                mysqli_close($db);
            }
        ?>
        </table>
    </div>
</div>


<!-- Message Modal -->
<div id="messageModal" class="modal">
    <h2 id="modalTitle"></h2>
    <form action="cmt_send_notification.php" method="POST"  id="notificationForm">
        <input type="hidden" id="modalAction" name="action">
        <input type="hidden" id="modalid_appoint" name="id_appoint">
        <textarea name="message" placeholder="Enter your message to the user" required></textarea>
        <button type="submit">Send</button>
        <button type="button" onclick="closeModal()">Close</button>
    </form>
</div>
<div id="overlay" class="overlay" onclick="closeModal()"></div>

<div id="overlay" class="overlay" onclick="closeModal()"></div>

<script>
    function openModal(action, id_appoint) {
        const modal = document.getElementById("messageModal");
        const overlay = document.getElementById("overlay");
        const title = document.getElementById("modalTitle");

        
        modal.classList.add("active");
        overlay.classList.add("active");

        
        document.getElementById("modalAction").value = action;
        document.getElementById("modalid_appoint").value = id_appoint;

        
    if (action === 'Cancel') {
    title.textContent = "Cancel Appointment - Send Message";

    
        if (message !== null) {
           
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "cmt_send_notification.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onload = function () {
                if (xhr.status === 200) {
                    alert("Appointment canceled and user notified!");
                    
                    const row = document.querySelector(`tr[data-id="${id_appoint}"]`);
                    if (row) {
                        row.remove();
                    }
                } else {
                    alert("Error canceling appointment. Please try again.");
                }
            };

            xhr.send(
                `action=${action}&appointment_id=${id_appoint}&message=${encodeURIComponent(message)}`
            );
        }
    
        } else if (action === 'Reschedule') {
            title.textContent = "Reschedule Appointment - Send Message";
        } else if (action === 'Approve') {
            title.textContent = "Approve Appointment - Send Message";
        }
    }

    function closeModal() {
        const modal = document.getElementById("messageModal");
        const overlay = document.getElementById("overlay");

        modal.classList.remove("active");
        overlay.classList.remove("active");
    }
            </script>
        </div>
    </body>
</html>