<?php
session_start(); 

$db = mysqli_connect("localhost:3307", "root", "");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['log_btn'])) {
    mysqli_select_db($db, "appointment");
    $studentnumber = mysqli_escape_string($db, $_POST['studentnumber']);
    $password = mysqli_escape_string($db, $_POST['password']);

    $qry = "SELECT * FROM tblregistration WHERE studentnumber='$studentnumber' AND password='$password'";
    $result = mysqli_query($db, $qry);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['studentnumber'] = $studentnumber; 
        echo '<script>window.location.href = "home.html";</script>'; 
        exit();
    } else {
        echo '<script>alert("Invalid Username or Password!");</script>';
        echo '<script>window.location.href = "login.html";</script>'; 
    }
}

mysqli_close($db);
?>