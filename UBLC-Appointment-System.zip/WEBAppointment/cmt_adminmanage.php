<?php
include('myconadmin.php');

if (isset($_POST['accept']) || isset($_POST['decline'])) {
    
    $id_appoint = mysqli_real_escape_string($connection, $_POST['id_appoint']);

    if (isset($_POST['accept'])) {
        $qryAcc = "UPDATE tblcmtappointment SET status = 'accepted' WHERE id_appoint = ?";
        $stmt = mysqli_prepare($connection, $qryAcc);
        mysqli_stmt_bind_param($stmt, "i", $id_appoint);

        if (mysqli_stmt_execute($stmt)) {
            echo '<script>alert("Accepted!")</script>';
        } else {
            echo 'Error updating status: ' . mysqli_error($connection);
        }
        mysqli_stmt_close($stmt);
    }

    if (isset($_POST['decline'])) {
        $qryDec = "UPDATE tblcmtappointment SET status = 'declined' WHERE id_appoint = ?";
        $stmt = mysqli_prepare($connection, $qryDec);
        mysqli_stmt_bind_param($stmt, "i", $id_appoint);

        if (mysqli_stmt_execute($stmt)) {
            echo '<script>alert("Declined!")</script>';
        } else {
            echo 'Error updating status: ' . mysqli_error($connection);
        }
        mysqli_stmt_close($stmt);
    }

    echo '<script>window.location.assign("cmt_admindashboard.php")</script>';
} else {
    echo 'No action selected!';
}

mysqli_close($connection);
?>
