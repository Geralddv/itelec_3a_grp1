<?php

$servername = "localhost:3307"; 
$username = "root";       
$password = "";           
$dbname = "appointment"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$studentnumber = $_POST['studentnumber'];
$password = $_POST['password']; 
$department = $_POST['department'];

$sql = "INSERT INTO tblregistration (fullname, email, studentnumber, password, department) 
        VALUES ('$fullname', '$email', '$studentnumber', '$password', '$department')";

if ($conn->query($sql) === TRUE) {
    session_start();
    $_SESSION['fullname'] = $fullname;
    $_SESSION['email'] = $email;
    $_SESSION['studentnumber'] = $studentnumber;
    $_SESSION['department'] = $department;

    header("Location: home.html");
    exit(); 
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>