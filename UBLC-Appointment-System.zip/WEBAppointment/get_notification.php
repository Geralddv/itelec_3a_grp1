<?php
session_start();

$db = mysqli_connect("localhost:3307", "root", "", "appointment");

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

if (!isset($_SESSION['studentnumber'])) {
    echo "Error: Not logged in.";
    exit();
}

$studentnumber = $_SESSION['studentnumber'];

$query = "SELECT id, id_appoint, action, message, status, created_at 
          FROM notifications 
          WHERE studentnumber = ? 
          ORDER BY created_at DESC";
$stmt = mysqli_prepare($db, $query);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, "s", $studentnumber);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div class='notification'>";
            echo "<h4>Action: " . htmlspecialchars($row['action']) . "</h4>";
            echo "<p>" . htmlspecialchars($row['message']) . "</p>";
            echo "<small>Received on: " . htmlspecialchars($row['created_at']) . "</small>";
            echo "<hr>";
            echo "</div>";
        }
    } else {
        echo "<p>No notifications found.</p>";
    }

    mysqli_stmt_close($stmt);
} else {
    echo "Error preparing query: " . mysqli_error($db);
}

mysqli_close($db);
?>
